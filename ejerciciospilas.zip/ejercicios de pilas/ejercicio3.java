public class ejercicio3 {
    public static void invertirCola(Cola cola) {
        Pila temp = new Pila();
        while (!cola.estaVacia()) temp.apilar(cola.sacar());
        while (!temp.estaVacia()) cola.enfilar(temp.sacar());
    }
    public static void main(String[] args) {
        Cola cola = new Cola();
        cola.enfilar(10);
        cola.enfilar(20);
        cola.enfilar(30);
        invertirCola(cola);
        while (!cola.estaVacia()) System.out.println(cola.sacar());
    }

    // Clases de apoyo de este ejercicio.
    public static class Cola {
        private Nodo primero;
        private Nodo ultimo;
        public boolean estaVacia() { return primero == null; }
        public void enfilar(Object dato) {
            Nodo nuevo = new Nodo(dato);
            if (estaVacia()) primero = nuevo;
            else ultimo.siguiente = nuevo;
            ultimo = nuevo;
        }
        public Object sacar() {
            if (estaVacia()) return null;
            Object dato = primero.contenido;
            primero = primero.siguiente;
            if (primero == null) ultimo = null;
            return dato;
        }
    }
    
    public static class Nodo {
        Object contenido;
        Nodo siguiente;
        public Nodo(Object contenido) { this.contenido = contenido; }
    }
    
    public static class Pila {
        Nodo primeroDeLaPila;

        // Metodo para apilar (Push)
        public void apilar(Object nuevoObjeto) {
            Nodo nuevoNodo = new Nodo(nuevoObjeto);
            nuevoNodo.siguiente = primeroDeLaPila;
            primeroDeLaPila = nuevoNodo;
        }

        // Metodo para sacar (Pop)
        public Object sacar() {
            if (primeroDeLaPila == null) return null;
            Object dato = primeroDeLaPila.contenido;
            primeroDeLaPila = primeroDeLaPila.siguiente;
            return dato;
        }

        public boolean estaVacia() {
            return primeroDeLaPila == null;
        }

        public Object verCima() {
            if (primeroDeLaPila == null) return null;
            return primeroDeLaPila.contenido;
        }
    }
    
}
