public class ejercicio4 {
    public static String buscarYExtraer(Pila armas, String objetivo) {
        Pila auxiliar = new Pila();
        String encontrada = null;
        // La pila contiene nombres de armas (String no nulos).
        while (!armas.estaVacia()) {
            String arma = (String) armas.sacar();
            if (arma.equals(objetivo)) {
                encontrada = arma;
                break;
            }
            auxiliar.apilar(arma);
        }
        while (!auxiliar.estaVacia()) armas.apilar(auxiliar.sacar());
        return encontrada;
    }
    public static void main(String[] args) {
        Pila armas = new Pila();
        armas.apilar("Espada");
        armas.apilar("Dagas de Vibranium");
        armas.apilar("Hacha");
        armas.apilar("Martillo");
        System.out.println("Extraida: " + buscarYExtraer(armas, "Dagas de Vibranium"));
        System.out.println("Restantes desde la cima:");
        while (!armas.estaVacia()) System.out.println(armas.sacar());
    }

    // Clases de apoyo de este ejercicio.
    public static class Nodo {
        Object contenido;
        Nodo siguiente;
        public Nodo(Object contenido) { this.contenido = contenido; }
    }
    
    public static class Pila {
        Nodo primeroDeLaPila;

        // Metodo para apilar (Push)
        public void apilar(Object nuevoObjeto) {
            Nodo nuevoNodo = new Nodo(nuevoObjeto);
            nuevoNodo.siguiente = primeroDeLaPila;
            primeroDeLaPila = nuevoNodo;
        }

        // Metodo para sacar (Pop)
        public Object sacar() {
            if (primeroDeLaPila == null) return null;
            Object dato = primeroDeLaPila.contenido;
            primeroDeLaPila = primeroDeLaPila.siguiente;
            return dato;
        }

        public boolean estaVacia() {
            return primeroDeLaPila == null;
        }

        public Object verCima() {
            if (primeroDeLaPila == null) return null;
            return primeroDeLaPila.contenido;
        }
    }
    
}
