public class ejercicio5 {
    public static void main(String[] args) {
        ColaNebula cola = new ColaNebula();
        cola.enfilar("A");
        cola.enfilar("B");
        cola.enfilar("C");
        System.out.println(cola.sacar());
        cola.enfilar("D");
        while (!cola.estaVacia()) System.out.println(cola.sacar());
    }

    // Clases de apoyo de este ejercicio.
    public static class ColaNebula {
        private Pila pilaEntrada = new Pila();
        private Pila pilaSalida = new Pila();
        public boolean estaVacia() {
            return pilaEntrada.estaVacia() && pilaSalida.estaVacia();
        }
        public void enfilar(Object dato) { pilaEntrada.apilar(dato); }
        public Object sacar() {
            // Solo se traspasan datos cuando la pila de salida esta vacia.
            if (pilaSalida.estaVacia()) {
                while (!pilaEntrada.estaVacia()) {
                    pilaSalida.apilar(pilaEntrada.sacar());
                }
            }
            return pilaSalida.sacar();
        }
    }
    
    public static class Nodo {
        Object contenido;
        Nodo siguiente;
        public Nodo(Object contenido) { this.contenido = contenido; }
    }
    
    public static class Pila {
        Nodo primeroDeLaPila;

        // Metodo para apilar (Push)
        public void apilar(Object nuevoObjeto) {
            Nodo nuevoNodo = new Nodo(nuevoObjeto);
            nuevoNodo.siguiente = primeroDeLaPila;
            primeroDeLaPila = nuevoNodo;
        }

        // Metodo para sacar (Pop)
        public Object sacar() {
            if (primeroDeLaPila == null) return null;
            Object dato = primeroDeLaPila.contenido;
            primeroDeLaPila = primeroDeLaPila.siguiente;
            return dato;
        }

        public boolean estaVacia() {
            return primeroDeLaPila == null;
        }

        public Object verCima() {
            if (primeroDeLaPila == null) return null;
            return primeroDeLaPila.contenido;
        }
    }
    
}
