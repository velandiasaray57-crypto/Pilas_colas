public class ejercicio6 {
    public static void ordenarPila(Pila gemas) {
        Pila auxiliar = new Pila();
        while (!gemas.estaVacia()) {
            int temp = (Integer) gemas.sacar();
            // Menor que temp: al regresar los datos, el mayor queda arriba.
            while (!auxiliar.estaVacia() && (Integer) auxiliar.verCima() < temp) {
                gemas.apilar(auxiliar.sacar());
            }
            auxiliar.apilar(temp);
        }
        while (!auxiliar.estaVacia()) gemas.apilar(auxiliar.sacar());
    }
    public static void main(String[] args) {
        Pila gemas = new Pila();
        gemas.apilar(30);
        gemas.apilar(10);
        gemas.apilar(40);
        gemas.apilar(20);
        ordenarPila(gemas);
        while (!gemas.estaVacia()) System.out.println(gemas.sacar());
    }

    // Clases de apoyo de este ejercicio.
    public static class Nodo {
        Object contenido;
        Nodo siguiente;
        public Nodo(Object contenido) { this.contenido = contenido; }
    }
    
    public static class Pila {
        Nodo primeroDeLaPila;

        // Metodo para apilar (Push)
        public void apilar(Object nuevoObjeto) {
            Nodo nuevoNodo = new Nodo(nuevoObjeto);
            nuevoNodo.siguiente = primeroDeLaPila;
            primeroDeLaPila = nuevoNodo;
        }

        // Metodo para sacar (Pop)
        public Object sacar() {
            if (primeroDeLaPila == null) return null;
            Object dato = primeroDeLaPila.contenido;
            primeroDeLaPila = primeroDeLaPila.siguiente;
            return dato;
        }

        public boolean estaVacia() {
            return primeroDeLaPila == null;
        }

        public Object verCima() {
            if (primeroDeLaPila == null) return null;
            return primeroDeLaPila.contenido;
        }
    }
    
}
