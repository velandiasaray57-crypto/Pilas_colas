public class ejercicio7 {
    public static void cargarEscudos(Cola cola) {
        while (!cola.estaVacia()) {
            Sector sector = (Sector) cola.sacar();
            if (sector.energiaFaltante <= 0) {
                System.out.println(sector.nombre + " ya esta al 100%.");
                continue;
            }
            int energia = 10;
            if (sector.energiaFaltante < 10) energia = sector.energiaFaltante;
            sector.energiaFaltante -= energia;
            System.out.println("Cargando " + sector.nombre + "... Restan "
                + sector.energiaFaltante + " para el 100%.");
            if (sector.energiaFaltante > 0) cola.enfilar(sector);
            else System.out.println(sector.nombre + " completado.");
        }
    }
    public static void main(String[] args) {
        Cola cola = new Cola();
        cola.enfilar(new Sector("Frontal", 25));
        cola.enfilar(new Sector("Trasero", 10));
        cola.enfilar(new Sector("Izquierdo", 15));
        cola.enfilar(new Sector("Derecho", 20));
        cargarEscudos(cola);
    }

    // Clases de apoyo de este ejercicio.
    public static class Cola {
        private Nodo primero;
        private Nodo ultimo;
        public boolean estaVacia() { return primero == null; }
        public void enfilar(Object dato) {
            Nodo nuevo = new Nodo(dato);
            if (estaVacia()) primero = nuevo;
            else ultimo.siguiente = nuevo;
            ultimo = nuevo;
        }
        public Object sacar() {
            if (estaVacia()) return null;
            Object dato = primero.contenido;
            primero = primero.siguiente;
            if (primero == null) ultimo = null;
            return dato;
        }
    }
    
    public static class Nodo {
        Object contenido;
        Nodo siguiente;
        public Nodo(Object contenido) { this.contenido = contenido; }
    }
    
    public static class Sector {
        String nombre;
        int energiaFaltante;
        public Sector(String nombre, int energiaFaltante) {
            this.nombre = nombre;
            this.energiaFaltante = energiaFaltante;
        }
    }
    
}
