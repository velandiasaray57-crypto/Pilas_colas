public class ejercicio1 {
    public static void main(String[] args) {
        PilaLimitada pila = new PilaLimitada(5);
        for (int i = 1; i <= 6; i++) pila.apilar("Bateria " + i);
        System.out.println("Cantidad: " + pila.getCantidadActual());
        System.out.println("Sale: " + pila.sacar());
        pila.apilar("Bateria nueva");
        System.out.println("Cantidad despues de reemplazar: " + pila.getCantidadActual());
        while (!pila.estaVacia()) System.out.println(pila.sacar());
    }

    // Clases de apoyo de este ejercicio.
    public static class Nodo {
        Object contenido;
        Nodo siguiente;
        public Nodo(Object contenido) { this.contenido = contenido; }
    }
    
    public static class Pila {
        Nodo primeroDeLaPila;

        // Metodo para apilar (Push)
        public void apilar(Object nuevoObjeto) {
            Nodo nuevoNodo = new Nodo(nuevoObjeto);
            nuevoNodo.siguiente = primeroDeLaPila;
            primeroDeLaPila = nuevoNodo;
        }

        // Metodo para sacar (Pop)
        public Object sacar() {
            if (primeroDeLaPila == null) return null;
            Object dato = primeroDeLaPila.contenido;
            primeroDeLaPila = primeroDeLaPila.siguiente;
            return dato;
        }

        public boolean estaVacia() {
            return primeroDeLaPila == null;
        }

        public Object verCima() {
            if (primeroDeLaPila == null) return null;
            return primeroDeLaPila.contenido;
        }
    }
    
    public static class PilaLimitada extends Pila {
        private int capacidadMaxima;
        private int cantidadActual;
        public PilaLimitada(int max) {
            if (max <= 0) throw new IllegalArgumentException("Capacidad no valida");
            capacidadMaxima = max;
            cantidadActual = 0;
        }
        @Override
        public void apilar(Object dato) {
            if (cantidadActual >= capacidadMaxima) {
                System.out.println("Error: pila llena. No se apilo: " + dato);
                return;
            }
            super.apilar(dato);
            cantidadActual++;
        }
        @Override
        public Object sacar() {
            if (estaVacia()) return null;
            Object dato = super.sacar();
            cantidadActual--;
            return dato;
        }
        public int getCantidadActual() { return cantidadActual; }
    }
    
}
