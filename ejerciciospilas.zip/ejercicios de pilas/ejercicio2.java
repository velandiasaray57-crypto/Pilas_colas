public class ejercicio2 {
    public static void reproducirSiguiente(Cola playlist) {
        if (playlist.estaVacia()) {
            System.out.println("No hay canciones.");
            return;
        }
        Object cancion = playlist.sacar();
        System.out.println("Reproduciendo: " + cancion);
        playlist.enfilar(cancion);
    }
    public static void main(String[] args) {
        Cola playlist = new Cola();
        playlist.enfilar("Cancion A");
        playlist.enfilar("Cancion B");
        playlist.enfilar("Cancion C");
        // Cada llamada representa un turno. Se muestran dos vueltas.
        for (int i = 0; i < 6; i++) reproducirSiguiente(playlist);
    }

    // Clases de apoyo de este ejercicio.
    public static class Cola {
        private Nodo primero;
        private Nodo ultimo;
        public boolean estaVacia() { return primero == null; }
        public void enfilar(Object dato) {
            Nodo nuevo = new Nodo(dato);
            if (estaVacia()) primero = nuevo;
            else ultimo.siguiente = nuevo;
            ultimo = nuevo;
        }
        public Object sacar() {
            if (estaVacia()) return null;
            Object dato = primero.contenido;
            primero = primero.siguiente;
            if (primero == null) ultimo = null;
            return dato;
        }
    }
    
    public static class Nodo {
        Object contenido;
        Nodo siguiente;
        public Nodo(Object contenido) { this.contenido = contenido; }
    }
    
}
